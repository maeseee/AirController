#!/bin/bash

function usage
{
	echo "usage "
	echo "	: on       ;relay 1~32(channel)/X(All)   ./relay.sh 192.168.1.100 on 1~32/X,  example: ./relay.sh 192.168.1.100 on 1;./relay.sh 192.168.1.100 on X"
	echo "	: off      ;relay 1~32(channel)/X(All)   ./relay.sh 192.168.1.100 off 1~32/X, example: ./relay.sh 192.168.1.100 off 1;./relay.sh 192.168.1.100 off X"
	echo "	: delay    ;example delay 5 second: ./relay.sh 192.168.1.100 delay on 1 5;./relay.sh 192.168.1.100 delay on X 5"
	echo "	: jogging  ;example jogging 500ms: ./relay.sh 192.168.1.100 jogging on 1 5;./relay.sh 192.168.1.100 jogging off X 5"
	echo "	: flash    ;example flash 500ms: ./relay.sh 192.168.1.100 flash on 1 5;./relay.sh 192.168.1.100 flash on 1 0;./relay.sh 192.168.1.100 flash off X 5"
	echo "	: toggle   ;example toggle 1: ./relay.sh 192.168.1.100 toggle 1;./relay.sh 192.168.1.100 toggle X"
	echo "	: raw      ;use raw dingtian-string protocol example: ./relay.sh 192.168.1.100 raw 12;./relay.sh 192.168.1.100 raw 22;"
	echo "	: status   ;get relay board relay and input status example: ./relay.sh 192.168.1.100 status"
}

function status()
{
	exec 8<>/dev/udp/$1/60001

	if(($?!=0));then
		echo "Open UDP port 60001 error!"
		exit 1;
	fi

	echo -en "00">&8

	timeout 1 cat<&8
	exec 8<&-
	exec 8>&-
	echo -e "\n"
}

function on_off()
{
	cmd=$2
	if [ ${2} == "off" ]; then
		cmd=2
	else
		cmd=1
	fi
	cmd+=$3
	echo ${cmd}

	echo -en "${cmd}" > /dev/udp/$1/60001
}

function delay()
{
	cmd=$2
	if [ ${2} == "off" ]; then
		cmd=2
	else
		cmd=1
	fi
	cmd+=$3
	cmd+=':'
	cmd+=$4
	echo ${cmd}

	echo -en "${cmd}" > /dev/udp/$1/60001
}

function jogging()
{
	cmd=$2
	if [ ${2} == "off" ]; then
		cmd=2
	else
		cmd=1
	fi
	cmd+=$3
	cmd+='*'
	cmd+=$4
	echo ${cmd}

	echo -en "${cmd}" > /dev/udp/$1/60001
}

function flash()
{
	cmd=$2
	if [ ${2} == "off" ]; then
		cmd=2
	else
		cmd=1
	fi
	cmd+=$3
	cmd+='F'
	cmd+=$4
	echo ${cmd}

	echo -en "${cmd}" > /dev/udp/$1/60001
}

function toggle()
{
	cmd='T'
	cmd+=$2
	echo ${cmd}

	echo -en "${cmd}" > /dev/udp/$1/60001
}

function raw()
{
	echo -en "$2" > /dev/udp/$1/60001
}

#---------------------------------
#main
#---------------------------------
if [ $# -eq 0 ];then
	usage
else
	case "$2" in
		status)
			status $1
			;;
		on)
			on_off $1 $2 $3
			;;
		off)
			on_off $1 $2 $3
			;;
		delay)
			delay $1 $3 $4 $5
			;;
		jogging)
			jogging $1 $3 $4 $5
			;;
		flash)
			flash $1 $3 $4 $5
			;;
		toggle)
			toggle $1 $3
			;;
		raw)
			raw $1 $3
			;;
		*)
			usage
			;;
	esac
fi

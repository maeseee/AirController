prompt:
Dingtian relay board support openHAB with MQTT


1 first time init openHAB and install "openhab-binding-mqtt"
openHAB console install "openhab-binding-mqtt" command:
feature:install openhab-binding-mqtt

2 stop openHAB

3 change and copy json
3.1 modify "org.openhab.core.thing.Thing.json" with you MQTT Broker IP,username,password
3.2 
change json file
"org.openhab.core.items.Item.json",
"org.openhab.core.thing.link.ItemChannelLink.json",
"org.openhab.core.thing.Thing.json"
example SN(7920) to you relay board SN

4 copy 2ch_config/4ch_config/8ch_config/16ch_config/32ch_config
"org.openhab.core.items.Item.json",
"org.openhab.core.thing.link.ItemChannelLink.json",
"org.openhab.core.thing.Thing.json"
to directory "openhab-3.2.0\userdata\jsondb"

5 start openHAB,then you can control relay with openHAB web(Settings->Model)
http://localhost:8080
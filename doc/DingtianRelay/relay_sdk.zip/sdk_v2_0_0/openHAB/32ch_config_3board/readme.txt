3 32ch relay board config example
example SN 8616, 8598, 8596
prompt:
Dingtian relay board support Home Assistant with MQTT


1 install Home Assistant

2 stop Home Assistant

3 replace configuration_2/4/8/16/32ch_*.yaml example SN(0) to you relay board SN

4 copy configuration_2/4/8/16/32ch_*.yaml to you Home Assistant yaml 

5 start Home Assistant
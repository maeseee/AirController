programing manual_en.pdf		relay programing manual
user_manual_en.pdf			relay user manual
cgitest_v2_2.exe			HTTP CGI api test tool
ipfinder_v2_2.exe			relay ip finder tool,use to find IP when you forget
net_test				sample ethernet wifi test relay
rs485_test				rs485 test relay
relay.sh				linux/unix shell test relay
relay.sh_how_to.txt			relay.sh how to use
linux_find_relay_ip.txt		how to find IP at linux/unix system
cgitest_v1_2.exe			relay board CGI API test tool
Domoticz_plugins			Domoticz plugins
MQTT				MQTT tools and doc
modbus_test_example.txt		modbus-rtu/ascii/tcp example
relay_spark_killer.png		spark killer
Demo_code			Demo code
powershell_example.txt		PowerShell ON/OFF relay example code(thanks Daniel Ivanchuk)
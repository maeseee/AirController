<?php
$old_2ch = "&0&2&1&1&";
$new_2ch = "&0&0&2&1&1&";
$old_4ch = "&0&4&1&1&1&1&";
$new_4ch = "&0&0&4&1&1&1&1&";
$old_8ch = "&0&8&1&1&1&1&1&1&1&1&";
$new_8ch = "&0&0&8&1&1&1&1&1&1&1&1&";
echo $old_2ch . "\n";
echo $new_2ch . "\n";
echo $old_4ch . "\n";
echo $new_4ch . "\n";
echo $old_8ch . "\n";
echo $new_8ch . "\n";

echo "\n --------------2ch old--------------\n";
$keys = input_to_array($old_2ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";

echo "\n --------------2ch new--------------\n";
$keys = input_to_array($new_2ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";

echo "\n --------------4ch old--------------\n";
$keys = input_to_array($old_4ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";
echo "input 3 value:". get_input_value($keys, 2) . "\n";
echo "input 4 value:". get_input_value($keys, 3) . "\n";

echo "\n --------------4ch new--------------\n";
$keys = input_to_array($new_4ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";
echo "input 3 value:". get_input_value($keys, 2) . "\n";
echo "input 4 value:". get_input_value($keys, 3) . "\n";

echo "\n --------------8ch old--------------\n";
$keys = input_to_array($old_8ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";
echo "input 3 value:". get_input_value($keys, 2) . "\n";
echo "input 4 value:". get_input_value($keys, 3) . "\n";
echo "input 5 value:". get_input_value($keys, 4) . "\n";
echo "input 6 value:". get_input_value($keys, 5) . "\n";
echo "input 7 value:". get_input_value($keys, 6) . "\n";
echo "input 8 value:". get_input_value($keys, 7) . "\n";

echo "\n --------------8ch new--------------\n";
$keys = input_to_array($new_8ch);
print_r($keys);
echo "channel cnt:". get_ch_cnt($keys) . "\n";
echo "channel cnt offset:". get_ch_offset($keys) . "\n";
echo "input 1 value:". get_input_value($keys, 0) . "\n";
echo "input 2 value:". get_input_value($keys, 1) . "\n";
echo "input 3 value:". get_input_value($keys, 2) . "\n";
echo "input 4 value:". get_input_value($keys, 3) . "\n";
echo "input 5 value:". get_input_value($keys, 4) . "\n";
echo "input 6 value:". get_input_value($keys, 5) . "\n";
echo "input 7 value:". get_input_value($keys, 6) . "\n";
echo "input 8 value:". get_input_value($keys, 7) . "\n";

function input_to_array($str)
{
    $keys = preg_split("/[&]+/", $str);
    array_splice($keys, sizeof($keys)-1, 1);
    array_splice($keys, 0, 1);

    return $keys;
}

function get_ch_cnt($keys)
{
    $keys_cnt = sizeof($keys);
    if( $keys_cnt < 3 )
    {
        return -1;
    }
    for($i=$keys_cnt-1; $i>=0; $i--)
    {
        if( $keys[$i] > 1 )
        {
            break;
        }
    }
    return $keys[$i];
}

function get_ch_offset($keys)
{
    $keys_cnt = sizeof($keys);
    if( $keys_cnt < 3 )
    {
        return -1;
    }
    for($i=$keys_cnt-1; $i>=0; $i--)
    {
        if( $keys[$i] > 1 )
        {
            break;
        }
    }
    return $i;
}

function get_input_value($keys, $input_index)
{
    $ch_offset = get_ch_offset($keys);
    if( $ch_offset < 0 )
    {
        return -1;
    }
    $ch_cnt = $keys[$ch_offset];
    if( $input_index >= $ch_cnt )
    {
        return -1;
    }
    $input_index += $ch_offset + 1;
    return $keys[$input_index];
}

?>

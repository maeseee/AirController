
  # Read and write from 165+595 shift register version2
  def write_read(outputs)
    var max_bit = self.count-1
    var inputs = 0

    gpio.digital_write(self.rck, 0)
    gpio.digital_write(self.pl, 1)

    for i:0..max_bit
      gpio.digital_write(self.sdi, outputs & 1)
      outputs >>= 1

      inputs >>= 1
      if( gpio.digital_read(self.q7) )
        inputs |= 0x80;

      gpio.digital_write(self.clk, 0)
      gpio.digital_write(self.clk, 1)
    end

    gpio.digital_write(self.rck, 1)
    gpio.digital_write(self.sdi, 1)

    gpio.digital_write(self.pl, 0)

    return inputs
  end
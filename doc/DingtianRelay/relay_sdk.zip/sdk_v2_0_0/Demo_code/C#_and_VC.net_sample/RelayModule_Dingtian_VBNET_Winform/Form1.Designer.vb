﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.button17 = New System.Windows.Forms.Button()
        Me.button16 = New System.Windows.Forms.Button()
        Me.button15 = New System.Windows.Forms.Button()
        Me.pictureBox8 = New System.Windows.Forms.PictureBox()
        Me.button14 = New System.Windows.Forms.Button()
        Me.button13 = New System.Windows.Forms.Button()
        Me.pictureBox7 = New System.Windows.Forms.PictureBox()
        Me.button12 = New System.Windows.Forms.Button()
        Me.button11 = New System.Windows.Forms.Button()
        Me.pictureBox6 = New System.Windows.Forms.PictureBox()
        Me.button10 = New System.Windows.Forms.Button()
        Me.button9 = New System.Windows.Forms.Button()
        Me.pictureBox5 = New System.Windows.Forms.PictureBox()
        Me.button8 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.pictureBox4 = New System.Windows.Forms.PictureBox()
        Me.pictureBox3 = New System.Windows.Forms.PictureBox()
        Me.pictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        CType(Me.pictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.Location = New System.Drawing.Point(445, 524)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(173, 18)
        Me.label9.TabIndex = 68
        Me.label9.Text = "Dingtian IOT Relay"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.Location = New System.Drawing.Point(445, 379)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(173, 18)
        Me.label8.TabIndex = 67
        Me.label8.Text = "Dingtian IOT Relay"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(445, 237)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(173, 18)
        Me.label7.TabIndex = 66
        Me.label7.Text = "Dingtian IOT Relay"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(454, 92)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(173, 18)
        Me.label6.TabIndex = 65
        Me.label6.Text = "Dingtian IOT Relay"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(98, 524)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(173, 18)
        Me.label5.TabIndex = 64
        Me.label5.Text = "Dingtian IOT Relay"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(98, 379)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(173, 18)
        Me.label4.TabIndex = 63
        Me.label4.Text = "Dingtian IOT Relay"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(98, 234)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(173, 18)
        Me.label3.TabIndex = 62
        Me.label3.Text = "Dingtian IOT Relay"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New System.Drawing.Point(98, 92)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(173, 18)
        Me.label2.TabIndex = 61
        Me.label2.Text = "Dingtian IOT Relay"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Verdana", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(174, 23)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(389, 42)
        Me.label1.TabIndex = 60
        Me.label1.Text = "Dingtian IOT Relay"
        '
        'button17
        '
        Me.button17.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button17.Location = New System.Drawing.Point(255, 686)
        Me.button17.Name = "button17"
        Me.button17.Size = New System.Drawing.Size(202, 50)
        Me.button17.TabIndex = 59
        Me.button17.Text = "Update Status"
        Me.button17.UseVisualStyleBackColor = True
        '
        'button16
        '
        Me.button16.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button16.Location = New System.Drawing.Point(531, 608)
        Me.button16.Name = "button16"
        Me.button16.Size = New System.Drawing.Size(116, 50)
        Me.button16.TabIndex = 58
        Me.button16.Text = "OFF"
        Me.button16.UseVisualStyleBackColor = True
        '
        'button15
        '
        Me.button15.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button15.Location = New System.Drawing.Point(531, 545)
        Me.button15.Name = "button15"
        Me.button15.Size = New System.Drawing.Size(116, 50)
        Me.button15.TabIndex = 57
        Me.button15.Text = "ON"
        Me.button15.UseVisualStyleBackColor = True
        '
        'pictureBox8
        '
        Me.pictureBox8.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox8.Location = New System.Drawing.Point(393, 545)
        Me.pictureBox8.Name = "pictureBox8"
        Me.pictureBox8.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox8.TabIndex = 56
        Me.pictureBox8.TabStop = False
        '
        'button14
        '
        Me.button14.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button14.Location = New System.Drawing.Point(531, 460)
        Me.button14.Name = "button14"
        Me.button14.Size = New System.Drawing.Size(116, 50)
        Me.button14.TabIndex = 55
        Me.button14.Text = "OFF"
        Me.button14.UseVisualStyleBackColor = True
        '
        'button13
        '
        Me.button13.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button13.Location = New System.Drawing.Point(531, 400)
        Me.button13.Name = "button13"
        Me.button13.Size = New System.Drawing.Size(116, 50)
        Me.button13.TabIndex = 54
        Me.button13.Text = "ON"
        Me.button13.UseVisualStyleBackColor = True
        '
        'pictureBox7
        '
        Me.pictureBox7.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox7.Location = New System.Drawing.Point(393, 400)
        Me.pictureBox7.Name = "pictureBox7"
        Me.pictureBox7.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox7.TabIndex = 53
        Me.pictureBox7.TabStop = False
        '
        'button12
        '
        Me.button12.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button12.Location = New System.Drawing.Point(531, 317)
        Me.button12.Name = "button12"
        Me.button12.Size = New System.Drawing.Size(116, 50)
        Me.button12.TabIndex = 52
        Me.button12.Text = "OFF"
        Me.button12.UseVisualStyleBackColor = True
        '
        'button11
        '
        Me.button11.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button11.Location = New System.Drawing.Point(531, 258)
        Me.button11.Name = "button11"
        Me.button11.Size = New System.Drawing.Size(116, 50)
        Me.button11.TabIndex = 51
        Me.button11.Text = "ON"
        Me.button11.UseVisualStyleBackColor = True
        '
        'pictureBox6
        '
        Me.pictureBox6.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox6.Location = New System.Drawing.Point(393, 258)
        Me.pictureBox6.Name = "pictureBox6"
        Me.pictureBox6.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox6.TabIndex = 50
        Me.pictureBox6.TabStop = False
        '
        'button10
        '
        Me.button10.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button10.Location = New System.Drawing.Point(531, 176)
        Me.button10.Name = "button10"
        Me.button10.Size = New System.Drawing.Size(116, 50)
        Me.button10.TabIndex = 49
        Me.button10.Text = "OFF"
        Me.button10.UseVisualStyleBackColor = True
        '
        'button9
        '
        Me.button9.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button9.Location = New System.Drawing.Point(531, 117)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(116, 50)
        Me.button9.TabIndex = 48
        Me.button9.Text = "ON"
        Me.button9.UseVisualStyleBackColor = True
        '
        'pictureBox5
        '
        Me.pictureBox5.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox5.Location = New System.Drawing.Point(393, 118)
        Me.pictureBox5.Name = "pictureBox5"
        Me.pictureBox5.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox5.TabIndex = 47
        Me.pictureBox5.TabStop = False
        '
        'button8
        '
        Me.button8.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button8.Location = New System.Drawing.Point(199, 608)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(116, 50)
        Me.button8.TabIndex = 46
        Me.button8.Text = "OFF"
        Me.button8.UseVisualStyleBackColor = True
        '
        'button7
        '
        Me.button7.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button7.Location = New System.Drawing.Point(199, 552)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(116, 50)
        Me.button7.TabIndex = 45
        Me.button7.Text = "ON"
        Me.button7.UseVisualStyleBackColor = True
        '
        'button6
        '
        Me.button6.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button6.Location = New System.Drawing.Point(199, 460)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(116, 50)
        Me.button6.TabIndex = 44
        Me.button6.Text = "OFF"
        Me.button6.UseVisualStyleBackColor = True
        '
        'button5
        '
        Me.button5.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button5.Location = New System.Drawing.Point(199, 400)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(116, 50)
        Me.button5.TabIndex = 43
        Me.button5.Text = "ON"
        Me.button5.UseVisualStyleBackColor = True
        '
        'pictureBox4
        '
        Me.pictureBox4.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox4.Location = New System.Drawing.Point(54, 545)
        Me.pictureBox4.Name = "pictureBox4"
        Me.pictureBox4.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox4.TabIndex = 42
        Me.pictureBox4.TabStop = False
        '
        'pictureBox3
        '
        Me.pictureBox3.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox3.Location = New System.Drawing.Point(54, 400)
        Me.pictureBox3.Name = "pictureBox3"
        Me.pictureBox3.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox3.TabIndex = 41
        Me.pictureBox3.TabStop = False
        '
        'pictureBox2
        '
        Me.pictureBox2.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox2.Location = New System.Drawing.Point(54, 258)
        Me.pictureBox2.Name = "pictureBox2"
        Me.pictureBox2.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox2.TabIndex = 40
        Me.pictureBox2.TabStop = False
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = Global.RelayModule_Dingtian_VBNET_Winform.My.Resources.Resources.off
        Me.pictureBox1.Location = New System.Drawing.Point(54, 118)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(111, 109)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 39
        Me.pictureBox1.TabStop = False
        '
        'button4
        '
        Me.button4.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button4.Location = New System.Drawing.Point(199, 321)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(116, 50)
        Me.button4.TabIndex = 38
        Me.button4.Text = "OFF"
        Me.button4.UseVisualStyleBackColor = True
        '
        'button3
        '
        Me.button3.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button3.Location = New System.Drawing.Point(199, 258)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(116, 50)
        Me.button3.TabIndex = 37
        Me.button3.Text = "ON"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button2.Location = New System.Drawing.Point(199, 177)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(116, 50)
        Me.button2.TabIndex = 36
        Me.button2.Text = "OFF"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.button1.Location = New System.Drawing.Point(199, 118)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(116, 50)
        Me.button1.TabIndex = 35
        Me.button1.Text = "ON"
        Me.button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(701, 759)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.button17)
        Me.Controls.Add(Me.button16)
        Me.Controls.Add(Me.button15)
        Me.Controls.Add(Me.pictureBox8)
        Me.Controls.Add(Me.button14)
        Me.Controls.Add(Me.button13)
        Me.Controls.Add(Me.pictureBox7)
        Me.Controls.Add(Me.button12)
        Me.Controls.Add(Me.button11)
        Me.Controls.Add(Me.pictureBox6)
        Me.Controls.Add(Me.button10)
        Me.Controls.Add(Me.button9)
        Me.Controls.Add(Me.pictureBox5)
        Me.Controls.Add(Me.button8)
        Me.Controls.Add(Me.button7)
        Me.Controls.Add(Me.button6)
        Me.Controls.Add(Me.button5)
        Me.Controls.Add(Me.pictureBox4)
        Me.Controls.Add(Me.pictureBox3)
        Me.Controls.Add(Me.pictureBox2)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.pictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents label9 As Label
    Private WithEvents label8 As Label
    Private WithEvents label7 As Label
    Private WithEvents label6 As Label
    Private WithEvents label5 As Label
    Private WithEvents label4 As Label
    Private WithEvents label3 As Label
    Private WithEvents label2 As Label
    Private WithEvents label1 As Label
    Private WithEvents button17 As Button
    Private WithEvents button16 As Button
    Private WithEvents button15 As Button
    Private WithEvents pictureBox8 As PictureBox
    Private WithEvents button14 As Button
    Private WithEvents button13 As Button
    Private WithEvents pictureBox7 As PictureBox
    Private WithEvents button12 As Button
    Private WithEvents button11 As Button
    Private WithEvents pictureBox6 As PictureBox
    Private WithEvents button10 As Button
    Private WithEvents button9 As Button
    Private WithEvents pictureBox5 As PictureBox
    Private WithEvents button8 As Button
    Private WithEvents button7 As Button
    Private WithEvents button6 As Button
    Private WithEvents button5 As Button
    Private WithEvents pictureBox4 As PictureBox
    Private WithEvents pictureBox3 As PictureBox
    Private WithEvents pictureBox2 As PictureBox
    Private WithEvents pictureBox1 As PictureBox
    Private WithEvents button4 As Button
    Private WithEvents button3 As Button
    Private WithEvents button2 As Button
    Private WithEvents button1 As Button
End Class
